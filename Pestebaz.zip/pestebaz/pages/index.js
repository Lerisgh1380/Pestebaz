export default function Home() {
  return (
    <main style={{ minHeight: '100vh', backgroundColor: '#fff', color: '#333' }}>
      <section style={{ textAlign: 'center', padding: '5rem 1rem', backgroundColor: '#d1fae5' }}>
        <h1 style={{ fontSize: '3rem', fontWeight: 'bold' }}>پسته‌باز</h1>
        <p style={{ marginTop: '1rem', fontSize: '1.25rem' }}>فروشگاه آنلاین پسته با طعم‌های خاص و جذاب</p>
      </section>

      <section style={{ padding: '4rem 1rem', maxWidth: '1200px', margin: '0 auto' }}>
        <h2 style={{ fontSize: '2rem', fontWeight: '600', marginBottom: '2rem', textAlign: 'center' }}>طعم‌های پسته</h2>
        <div style={{ display: 'grid', gap: '1.5rem', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))' }}>
          {[
            { name: "پسته وانیلی", flavor: "وانیلی" },
            { name: "پسته شکلاتی", flavor: "شکلاتی" },
            { name: "پسته فلفلی", flavor: "فلفلی" },
            { name: "پکیج چند طعمه", flavor: "ترکیبی" },
          ].map(({ name, flavor }) => (
            <div key={flavor} style={{ borderRadius: '1rem', boxShadow: '0 4px 10px rgba(0,0,0,0.1)', padding: '1.5rem', backgroundColor: '#fff', border: '1px solid #eee', transition: '0.3s' }}>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginBottom: '0.5rem' }}>{name}</h3>
              <p style={{ color: '#666' }}>طعم {flavor} خوشمزه و متفاوت</p>
              <button style={{ marginTop: '1rem', backgroundColor: '#16a34a', color: '#fff', padding: '0.5rem 1rem', borderRadius: '0.75rem', border: 'none' }}>افزودن به سبد</button>
            </div>
          ))}
        </div>
      </section>

      <footer style={{ padding: '2.5rem 1rem', textAlign: 'center', backgroundColor: '#f3f4f6', marginTop: '5rem' }}>
        <p>© 2025 پسته‌باز. همه حقوق محفوظ است.</p>
      </footer>
    </main>
  );
}