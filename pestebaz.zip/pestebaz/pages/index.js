export default function Home() {
  return (
    <main className="min-h-screen bg-white text-gray-800">
      <section className="text-center py-20 bg-green-100">
        <h1 className="text-5xl font-bold">پسته‌باز</h1>
        <p className="mt-4 text-xl">فروشگاه آنلاین پسته با طعم‌های خاص و جذاب</p>
      </section>

      <section className="py-16 px-4 max-w-6xl mx-auto">
        <h2 className="text-3xl font-semibold mb-8 text-center">طعم‌های پسته</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { name: "پسته وانیلی", flavor: "وانیلی" },
            { name: "پسته شکلاتی", flavor: "شکلاتی" },
            { name: "پسته فلفلی", flavor: "فلفلی" },
            { name: "پکیج چند طعمه", flavor: "ترکیبی" },
          ].map(({ name, flavor }) => (
            <div key={flavor} className="rounded-2xl shadow-md p-6 bg-white border hover:shadow-xl transition duration-300">
              <h3 className="text-xl font-bold mb-2">{name}</h3>
              <p className="text-gray-600">طعم {flavor} خوشمزه و متفاوت</p>
              <button className="mt-4 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-xl">افزودن به سبد</button>
            </div>
          ))}
        </div>
      </section>

      <footer className="py-10 text-center bg-gray-100 mt-20">
        <p>© 2025 پسته‌باز. همه حقوق محفوظ است.</p>
      </footer>
    </main>
  );
}